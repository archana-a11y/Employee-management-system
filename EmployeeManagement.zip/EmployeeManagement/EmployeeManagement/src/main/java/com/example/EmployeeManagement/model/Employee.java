package com.example.EmployeeManagement.model;

import jakarta.persistence.*;
import jakarta.persistence.Table;

@Entity
@Table(name="employee")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long id;
     private String name;
     private String Department;
     private String Phone;
     private String email;
     
     public Employee() {}
     
	 public Employee(String name, String department, String phone, String email) {
		super();
		this.name = name;
		Department = department;
		Phone = phone;
		this.email = email;
	}

	 public Long getId() {
		 return id;
	 }

	 public void setId(Long id) {
		 this.id = id;
	 }

	 public String getName() {
		 return name;
	 }

	 public void setName(String name) {
		 this.name = name;
	 }

	 public String getDepartment() {
		 return Department;
	 }

	 public void setDepartment(String department) {
		 Department = department;
	 }

	 public String getPhone() {
		 return Phone;
	 }

	 public void setPhone(String phone) {
		 Phone = phone;
	 }

	 public String getEmail() {
		 return email;
	 }

	 public void setEmail(String email) {
		 this.email = email;
	 }
	 	 
}
