package com.example.EmployeeManagement.service;

import java.util.List;
import java.util.Optional;

import com.example.EmployeeManagement.model.Employee;




public interface EmployeeService {
    List<Employee> getAllEmployees();
    Optional<Employee> getEmployeeById(Long id);
    Employee createEmployee(Employee employee);
    Employee updateEmployee(Long id, Employee updatedEmployee);
    void deleteEmployee(Long id);
}

